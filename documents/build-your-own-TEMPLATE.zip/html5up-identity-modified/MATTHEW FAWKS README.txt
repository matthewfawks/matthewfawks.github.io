---MATTHEW FAWKS | matthewfawks.com | as of May 31, 2020---

HTML5 UP README.txt and HTML5 UP LICENSE.txt (in the "license-readme" folder), are the overarching documents that should govern any user's particular use of the code and other related assets within this file download.

In accordance with the CC BY 3.0 license that governs this work, I, Matthew Fawks, am making the following attribution:

	"This work, "Build-Your-Own-TEMPLATE" (A.K.A. "html5up-identity-modified"), is a derivative of "Creative Commons Identity Template" (https://html5up.net/identity) by HTML5 UP (https://html5up.net/license), used under CC BY (http://creativecommons.org/licenses/by/3.0/). Accordingly, "Build-Your-Own-TEMPLATE" (A.K.A. "html5up-identity-modified") is licensed under CC BY (http://creativecommons.org/licenses/by/3.0/) by Matthew Fawks (https://www.matthewfawks.com."

I have no intentions of degrading the platform and products that HTML5 Up distributes, and my purpose in distributing this work is solely to provide an educational opportunity to people otherwise unfamiliar with the coding languages necessary to hosting a website.

I have attempted to make the work as easy as possible to plug into from this standpoint, and I have left all necessary attributions on and within the document(s).

Enjoy!


Credits:
	Base Template Code (HTML, CSS, and JavaScript):
		HTML5 UP (html5up.com)
	
	Demo Images:
		Matthew Fawks (matthewfawks.com/collection)

	Icons:
		Font Awesome (fontawesome.io)

	Other:
		Responsive Tools (github.com/ajlkn/responsive-tools)